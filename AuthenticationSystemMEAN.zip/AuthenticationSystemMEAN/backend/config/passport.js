const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');

module.exports = function (passport) {
    passport.use('local-login',
        new LocalStrategy({ usernameField: "email", passwordField: "password"}, (email, password, done) => {
            console.log('comee')
            console.log(email, password)
            Users.findOne({ f_email: email })
                .then(data => {
                    if (!data) {
                        return done(null, false, { message: "not" });
                    }

                    Users.findOne({ f_password: password}).then(data1 => {
                        if (!data1) {
                            return done(null, false, { message: "incorrect" });
                        } else {
                            return done(null, data, { message: "success" });

                        }
                    });
                })
                .catch(err => console.log(err));
        })
    )
    passport.serializeUser((user, done) => {
        done(null, user);
    });
    passport.deserializeUser((user, done) => {
        done(null, user);
    });

}