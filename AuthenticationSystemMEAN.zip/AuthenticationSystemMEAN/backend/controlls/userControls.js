const passport = require('passport');
const mongoose = require('mongoose');
module.exports = {
    login: (req, res, next) => {
        console.log(req.body)
        passport.authenticate('local-login', function (err, user, info) {
            if (err) console.log(err);

            if (err) { return res.send(err); }
            if (!user) { return res.send(info); }
            req.logIn(user, async function (err) {
                if (err) { return res.send(err); }
                console.log(user)   
                console.log("hid login")
                console.log(user.f_type)
                console.log(req.body)
                if (user.f_type == req.body.type && user.f_email == req.body.email && user.f_password == req.body.password) {
                    console.log("you are in type")
                    res.json({ message: user });
                } else {
                    console.log("you are in type different")
                    res.json({ message: "incorrect" });

                }
            });
        })(req, res, next);
    }
}