var express = require("express");
var router = express.Router();

var {login} = require('../controlls/userControls');

const { ensureAuthenticated } = require("../config/auth");

// router.post('/login',login);
router.post('/login',login)



module.exports = router;