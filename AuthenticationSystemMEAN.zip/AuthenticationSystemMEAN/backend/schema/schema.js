const mongoose = require('mongoose');

const usersSchema = new mongoose.Schema({
    f_firstname : String,
    f_lastname : String,
    f_email : String,
    f_password : String,
    f_type : String,
    f_status : Boolean,
    f_createdDate : {type:Date,default:Date.now},
},{collection:"users"});
module.exports = Users = mongoose.model("users",usersSchema);