import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServicesService } from 'src/app/services/services.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  type = "S";
  formsvalue: {};
  successResult: any;
  constructor(private formBuilder: FormBuilder, private router: Router, private services: ServicesService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]],
      type: ['', Validators.required],
    });
  }
  get f() { return this.loginForm.controls; }
  onSubmit() {
    this.submitted = true;

    if (this.loginForm.invalid) {
      return;
    } else {
      this.formsvalue = {
        email: this.loginForm.value.email,
        password: this.loginForm.value.password,
        type: this.loginForm.value.type
      }
      console.log(this.formsvalue)
      this.services.loginServices(this.formsvalue).subscribe((data) => {
        this.successResult = data;
        console.log(this.successResult)
        if(this.successResult.message == "not" || this.successResult.message == "incorrect"){
          this.toastr.error("Error : Crendentials is not valid!", "incorrect")
        }else{
          // console.table(this.successResult)
          // this.toastr.success("you are loging in successfully", "successfull")
          localStorage.setItem('userfirstname', this.successResult.message.f_firstname);
          localStorage.setItem('userlastname', this.successResult.message.f_lastname);
          localStorage.setItem('useremail', this.successResult.message.f_email);
          if(this.successResult.message.f_type == "A"){
            this.router.navigateByUrl('/admin');
          }else if(this.successResult.message.f_type == "T"){
            window.location.assign('/teacher');
          }else if(this.successResult.message.f_type == "S"){
            window.location.assign('/student');
          }else if(this.successResult.message.f_type == "P"){
            window.location.assign('/parent');
          }
        }
      })
    }
  }
 
}
