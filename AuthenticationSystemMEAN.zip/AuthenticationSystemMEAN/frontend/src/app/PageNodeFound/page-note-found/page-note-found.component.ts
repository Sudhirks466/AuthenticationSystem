import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-note-found',
  templateUrl: './page-note-found.component.html',
  styleUrls: ['./page-note-found.component.css']
})
export class PageNoteFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
