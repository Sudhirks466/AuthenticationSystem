import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  localstoragevalue: { userfname: string; userlname: string; useremail: string; };

  constructor(private toastr: ToastrService,private router: Router) { }

  ngOnInit(): void {
    this.getLocalStoragevalue();
  }
  getLocalStoragevalue() {
    if(localStorage.getItem('userfirstname') == null && localStorage.getItem('userlastname') == null && localStorage.getItem('useremail') == null){
      this.router.navigateByUrl('/');
    }else{
      this.toastr.success("You are loggin in successfully!", "Successfull")
    }
    this.localstoragevalue = {
      userfname: localStorage.getItem('userfirstname'),
      userlname: localStorage.getItem('userlastname'),
      useremail: localStorage.getItem('useremail')
    }
    // console.log(this.localstoragevalue)
  }
  logout(){
    localStorage.clear();
    this.getLocalStoragevalue();
  }
}
