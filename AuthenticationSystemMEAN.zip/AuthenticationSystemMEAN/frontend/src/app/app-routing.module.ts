import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageNoteFoundComponent } from './PageNodeFound/page-note-found/page-note-found.component';
import { LoginComponent } from './auth/login/login.component';
import { AdminComponent } from './dashboard/admin/admin.component';
import { TeacherComponent } from './dashboard/teacher/teacher.component';
import { StudentComponent } from './dashboard/student/student.component';
import { ParentComponent } from './dashboard/parent/parent.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'teacher', component: TeacherComponent },
  { path: 'student', component: StudentComponent },
  { path: 'parent', component: ParentComponent },
  { path: '**', component: PageNoteFoundComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
