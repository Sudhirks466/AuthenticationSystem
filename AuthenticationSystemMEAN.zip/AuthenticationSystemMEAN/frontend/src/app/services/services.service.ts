import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {
  url = 'http://localhost:7853/';
  constructor(private http: HttpClient, private routes: ActivatedRoute) { }
  loginServices(rec){
    return this.http.post(`${this.url}login`,rec)
  }
}
